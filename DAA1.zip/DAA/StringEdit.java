import java.util.Scanner;

public class StringEdit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String1: ");
        String x=sc.nextLine();
        System.out.println("Enter String2: ");
        String y=sc.nextLine();
        int result = minEditDist(x,y);
        System.out.println("Min no of operations required = "+result);
    }
    public static int minEditDist(String p,String q){
        int m = p.length();
        int n = q.length();
        int table[][] = new int[m+1][n+1];
        for(int i = 0;i < m;i++){
            for (int j = 0; j < n; j++) {
                if(i == 0 || j == 0){
                    if(i == 0){
                    table[i][j] = j;
                    }else{
                        table[i][j] = i;
                    }
                }else if(p.charAt(i-1) == q.charAt(j-1)){
                    table[i][j] = table[i-1][j-1];
                }else{
                    table[i][j] = Math.min(Math.min(table[i-1][j],table[i-1][j-1]),table[i][j-1])+1;
                }
            }
        }
        return table[m-1][n-1];
    }
    
}