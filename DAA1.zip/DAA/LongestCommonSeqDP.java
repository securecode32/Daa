import java.util.Scanner;

public class LongestCommonSeqDP
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter String1: ");
        String s1=sc.nextLine();
        System.out.println("Enter String2: ");
        String s2=sc.nextLine();
        int result = longestSeq(s1,s2);
        System.out.println("Length of longest common subsequene String: "+result);
    }
    public static int longestSeq(String p,String q)
    {
        int m = p.length();
        int n = q.length();
        int table[][] = new int[m+1][n+1];
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i==0 || j==0){
                    table[i][j] = 0;
                }
                else if(p.charAt(i) == q.charAt(j)){
                    table[i][j] = table[i-1][j-1]+1;
                }
                else{
                    table[i][j]=Math.max(table[i-1][j],table[i][j-1]);
                }
            }
        }
        return table[m-1][n-1];
    }
}