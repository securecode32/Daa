import java.util.Scanner;

public class MinMax {
    static class Result{
        int max;
        int min;
        public Result(int x,int y){
            min = x;
            max = y;
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.println("Enter number of elements: ");
        n = sc.nextInt();
        int[] a = new int[n];
        System.out.println("Enter the "+n+" elements");
        for(int i= 0;i< n;i++){
            a[i] = sc.nextInt();
        }
        Result r = findMaxMin(a,0,a.length-1); 
        System.out.println("Max = "+r.max+" Min = "+r.min);
    }
    public static Result findMaxMin(int a[],int start,int end){
        if(start == end){
            return new Result(a[start],a[end]);
        }
        else if(end - start == 1){
            if(a[start]<a[end]){
                return new Result(a[start],a[end]);
            }else{
                return new Result(a[end],a[start]);
            }
        }
        else{
            int mid = (start + end)/2;
            Result lr = findMaxMin(a,start,mid);
            Result rr = findMaxMin(a, mid+1, end);
            int min = (lr.min < rr.min)?lr.min:rr.min;
            int max = (lr.max > rr.max)?lr.max:rr.max;
            return new Result(min,max);
        }
        
    }
}